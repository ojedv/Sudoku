public class MainPruebas {
    public static void main(String[] args) {
        Sudoku sudo = new Sudoku();
        System.out.println(sudo.toString());
    }

}
