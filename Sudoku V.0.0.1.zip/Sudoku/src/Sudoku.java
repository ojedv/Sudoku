import java.util.Arrays;

public class Sudoku {
    int[][] sudoku = new int[9][9];

    public Sudoku(){
        for(int i = 0; i < 8; i++){
            for(int y = 0; y < 8; y++){
                this.sudoku[i][y] = 0;
            }

        }
    }
    public void rellenarNumSudoku(puntoMatriz xy, int valor){
        this.sudoku[xy.getX()][xy.getY()] = valor;

    }

    // Esta funcion evalua antes de introducir el numero en el sudoku si dicho numero ya existe en esa columna/fila/bloque para no continuar. Aunque use el backtracking para rellenar el otro sudoku y solo tenga que comparar dejo este metodo ya que me parece muy util para la validacion.
    public boolean validarNumSudoku(puntoMatriz xy, int valor) {
        // Validar en la fila
        for (int i = 0; i < 9; i++) {
            if (sudoku[xy.getX()][i] == valor) {
                return false; // El valor ya existe en la fila
            }
        }

        // Validar en la columna
        for (int i = 0; i < 9; i++) {
            if (sudoku[i][xy.getY()] == valor) {
                return false; // El valor ya existe en la columna
            }
        }

        // Validar en el bloque 3x3
        int startX = (xy.getX() / 3) * 3; // Inicio del bloque en la fila
        int startY = (xy.getY() / 3) * 3; // Inicio del bloque en la columna
        for (int i = startX; i < startX + 3; i++) {
            for (int j = startY; j < startY + 3; j++) {
                if (sudoku[i][j] == valor) {
                    return false; // El valor ya existe en el bloque 3x3
                }
            }
        }

        // Si pasa todas las validaciones, el número es válido
        return true;
    }

    @Override
    public String toString() {
        return "Sudoku{" +
                "sudoku=" + Arrays.deepToString(sudoku) +
                '}';
    }
}
