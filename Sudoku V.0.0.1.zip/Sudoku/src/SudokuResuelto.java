public class SudokuResuelto {

}
